<?php 


class Comment extends CI_Model{

public function get_comment(){


$this->load->database();
$dt=$this->db->query("select * from feed");
return $dt->result_array();
}


public function insert_data($commetdata){

$this->load->database();
  $this->db->insert('feed',$commetdata);  

}

}





?>