<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>CodeIgniter Assignment</title>
 <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 19px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}

	code {
		font-family: Consolas, Monaco, Courier New, Courier, monospace;
		font-size: 12px;
		background-color: #f9f9f9;
		border: 1px solid #D0D0D0;
		color: #002166;
		display: block;
		margin: 14px 0 14px 0;
		padding: 12px 10px 12px 10px;
	}

	#body {
		margin: 0 15px 0 15px;
	}

	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}

	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
	.uname {
    
    font-size: 18px;
}
.uname1 {
    
        font-size: 16px;
    padding-left: 15px;
    font-family: monospace;
    color: orangered;
}
.ucomment {
    
    font-size: 18px;
    padding-bottom: 15px;

}
.ucomment1{
    font-size: 16px;
    padding-left: 15px;
    padding-bottom: 15px;
    font-family: monospace;
    color: darkgreen;
}
	</style>

</head>
<body>


	<h1>CodeIgniter Assignment</h1>
<div class="container">
<table>
	<?php foreach($comments as $comment) {?>

	<tr>
				<td class="uname">Name: </td>
				<td class="uname1">
				<?php echo $comment['name'];?>
			    </td>
	</tr>
	<tr>
				<td class="ucomment">Comment: </td>
				<td class="ucomment1">
					<?php echo $comment['comment'];?>
				</td>

</tr>
<?php }?>
</table>

	
		
  <h2>Enter Your Comment Here</h2>
  <form method="post"action="savedata">
    <div class="form-group">
      <label for="name">Name:</label>
      <input type="text" class="form-control" id="email" placeholder="Enter Your Name" name="name">
    </div>
    <div class="form-group">
      <label for="comment">Comment:</label>
      <textarea class="form-control" rows="5" name="comment"></textarea>
    </div>
   
    <button type="submit" class="btn btn-default">Comment</button>
  </form>


		
	</div>

	

</body>
</html>