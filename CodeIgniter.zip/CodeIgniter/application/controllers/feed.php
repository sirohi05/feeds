<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Feed extends CI_Controller {

	
	public function index()
	{

		$this->load->model('comment');
		$data['comments']=$this->comment->get_comment();
		$this->load->view('feeds',$data);
	}

	public function savedata(){

    if($this->input->post('name')!=''&& $this->input->post('comment')!=''){
    $commetdata = array(  
                        'name'     => $this->input->post('name'),  
                        'comment'  => $this->input->post('comment'),  
                         
                        ); 

                $this->load->model('comment');
               $this->comment->insert_data($commetdata);  
               $this->load->helper('url'); 
         redirect('http://localhost/codeigniter/index.php/feed/', 'refresh');  
}
else{

    print_r("Please Enter Both Fields");


}
	}
}

